param([string]$BaseUrl = "http://localhost:5084")
$ErrorActionPreference = "Stop"
function Check($ok,$name) { if (-not $ok) { throw "ERRORE: $name" }; Write-Host "OK: $name" }
$ping = Invoke-RestMethod "$BaseUrl/api/ping"
Check ($ping.status -eq 'ok') 'Ping'
$initial = @(Invoke-RestMethod "$BaseUrl/api/ideas")
Check ($initial.Count -ge 1) 'GET lista iniziale'
$created = Invoke-RestMethod "$BaseUrl/api/ideas" -Method Post -ContentType 'application/json' -Body '{"title":"   Laboratorio foto   "}'
Check ($created.title -eq 'Laboratorio foto' -and -not $created.approved) 'POST + Trim'
$all = @(Invoke-RestMethod "$BaseUrl/api/ideas")
Check (@($all | Where-Object { $_.id -eq $created.id }).Count -eq 1) 'POST persistito'
$updated = Invoke-RestMethod "$BaseUrl/api/ideas/$($created.id)" -Method Patch -ContentType 'application/json' -Body '{"state":true}'
Check ($updated.approved -eq $true) 'PATCH'
Invoke-RestMethod "$BaseUrl/api/ideas/$($created.id)" -Method Delete | Out-Null
$after = @(Invoke-RestMethod "$BaseUrl/api/ideas")
Check (@($after | Where-Object { $_.id -eq $created.id }).Count -eq 0) 'DELETE'
Write-Host 'API principali verificate. Controllare a mano 400, 404 e browser.'
