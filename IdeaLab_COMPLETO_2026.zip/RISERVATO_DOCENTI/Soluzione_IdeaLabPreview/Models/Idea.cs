namespace IdeaLabPreview;

// Classi semplici: le proprieta' possono essere lette e cambiate.
public class Idea
{
    public int Id { get; set; }
    public string Title { get; set; } = "";
    public bool Approved { get; set; }
}

public class CreateIdeaRequest
{
    public string? Title { get; set; }
}

public class UpdateIdeaState
{
    public bool State { get; set; }
}
