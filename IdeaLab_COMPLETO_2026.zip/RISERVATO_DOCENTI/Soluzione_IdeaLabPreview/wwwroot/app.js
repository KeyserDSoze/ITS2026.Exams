const API = '/api/ideas';
const list = document.querySelector('#idea-list');
const form = document.querySelector('#idea-form');
const input = document.querySelector('#title');
const message = document.querySelector('#message');
const emptyMessage = document.querySelector('#empty-message');

async function checkServer() {
  try {
    const response = await fetch('/api/ping');
    const data = await response.json();
    document.querySelector('#server-status').textContent = data.message;
    document.querySelector('#server-dot').classList.add('online');
  } catch (error) {
    document.querySelector('#server-status').textContent = 'Server non raggiungibile';
    document.querySelector('#server-dot').classList.add('offline');
  }
}

async function loadIdeas() {
  try {
    const response = await fetch(API);
    if (!response.ok) throw new Error('Errore nella lettura');
    const ideas = await response.json();
    renderIdeas(ideas);
  } catch (error) {
    showMessage('Impossibile leggere le proposte', true);
  }
}

function renderIdeas(ideas) {
  list.replaceChildren();
  emptyMessage.hidden = ideas.length > 0;
  for (const idea of ideas) {
    const li = document.createElement('li');
    li.className = 'idea-card';
    const text = document.createElement('span');
    text.textContent = idea.title + ' - ' + (idea.approved ? 'Approvata' : 'Da valutare');
    li.append(text);

    const buttons = document.createElement('div');
    buttons.className = 'idea-actions';
    const updateButton = document.createElement('button');
    updateButton.textContent = idea.approved ? 'Riapri' : 'Approva';
    updateButton.addEventListener('click', () => updateIdea(idea.id, !idea.approved));
    const deleteButton = document.createElement('button');
    deleteButton.className = 'delete';
    deleteButton.textContent = 'Elimina';
    deleteButton.addEventListener('click', () => deleteIdea(idea.id));
    buttons.append(updateButton, deleteButton);
    li.append(buttons);
    list.append(li);
  }
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    const response = await fetch(API, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: input.value })
    });
    if (!response.ok) {
      showMessage('Titolo non valido o errore del server', true);
      return;
    }
    input.value = '';
    showMessage('Proposta aggiunta');
    await loadIdeas();
  } catch (error) { showMessage('Errore di rete', true); }
});

async function updateIdea(id, state) {
  try {
    const response = await fetch(API + '/' + id, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ state: state })
    });
    if (!response.ok) throw new Error('Errore');
    showMessage('Stato aggiornato');
    await loadIdeas();
  } catch (error) { showMessage('Impossibile aggiornare', true); }
}

async function deleteIdea(id) {
  try {
    const response = await fetch(API + '/' + id, { method: 'DELETE' });
    if (!response.ok) throw new Error('Errore');
    showMessage('Proposta eliminata');
    await loadIdeas();
  } catch (error) { showMessage('Impossibile eliminare', true); }
}

function showMessage(text, isError = false) {
  message.textContent = text;
  message.className = isError ? 'error' : 'success';
}

checkServer();
loadIdeas();
