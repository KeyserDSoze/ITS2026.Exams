namespace IdeaLabPreview;

// I dati sono solo in memoria: non serve un database.
public class IdeaStore
{
    public List<Idea> Items { get; set; } = new List<Idea>
    {
        new Idea { Id = 1, Title = "Laboratorio robotica", Approved = false }
    };

    public int NextId { get; set; } = 2;
}
