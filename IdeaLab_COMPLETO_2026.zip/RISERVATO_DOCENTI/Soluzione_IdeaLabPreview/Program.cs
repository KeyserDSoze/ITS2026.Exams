using IdeaLabPreview;

var builder = WebApplication.CreateBuilder(args);

// La DEPENDENCY INJECTION e' gia' pronta.
builder.Services.AddSingleton<IdeaStore>();

var app = builder.Build();

// I MIDDLEWARE sono gia' pronti: servono la pagina e gli altri file web.
app.UseDefaultFiles();
app.UseStaticFiles();

// Questo e' un esempio completo di Minimal API. NON modificarlo.
app.MapGet("/api/ping", () => Results.Ok(new
{
    status = "ok",
    message = "Server online"
}));

app.MapGet("/api/ideas", (IdeaStore store) => Results.Ok(store.Items));

app.MapPost("/api/ideas", (CreateIdeaRequest request, IdeaStore store) =>
{
    var title = request.Title?.Trim();
    if (string.IsNullOrWhiteSpace(title))
        return Results.BadRequest(new { error = "Il titolo e' obbligatorio" });

    var idea = new Idea
    {
        Id = store.NextId,
        Title = title,
        Approved = false
    };
    store.NextId++;
    store.Items.Add(idea);
    return Results.Created($"/api/ideas/{idea.Id}", idea);
});

// Find + assegnazione diretta: nessun record, init, with o FindIndex.
app.MapPatch("/api/ideas/{id:int}", (int id, UpdateIdeaState request, IdeaStore store) =>
{
    var idea = store.Items.Find(x => x.Id == id);
    if (idea == null) return Results.NotFound();
    idea.Approved = request.State;
    return Results.Ok(idea);
});

app.MapDelete("/api/ideas/{id:int}", (int id, IdeaStore store) =>
{
    var idea = store.Items.Find(x => x.Id == id);
    if (idea == null) return Results.NotFound();
    store.Items.Remove(idea);
    return Results.NoContent();
});

app.Run();
