# Guida docente - IdeaLab facile

- Non inviare ai candidati la cartella RISERVATO_DOCENTI.
- Per la preview distribuire **solo STUDENTI**.
- Aprire la soluzione .NET da RISERVATO_DOCENTI/Soluzione_IdeaLabPreview.
- Il server va avviato prima di usare `verifica_api.ps1`.
- Tutti i modelli sono `class`, tutte le proprietà sono `get; set;`.
- Nel PATCH: `Find` e `idea.Approved = request.State`.
- Nel DELETE: `Find` e `store.Items.Remove(idea)`.
- La prova è semplificata: niente ricerca, autenticazione, database o librerie frontend.
- Correzione: 20 punti pratica, 10 teoria, solo nella guida docente PDF.
- La correzione frontend va fatta anche dal browser, non solo via HTTP.
