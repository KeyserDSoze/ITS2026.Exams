# IdeaLab ITS - Simulazione Development facile

Questo e' un esempio di prova **non ufficiale**, preparato per la preview in aula.
Lo ZIP contiene il progetto .NET 10, una prova pratica e una prova teorica separate.

## Come partire

1. Installare .NET SDK 10 e l'estensione C# di Microsoft per VS Code.
2. In VS Code: **File -> Apri cartella -> IdeaLabPreview** (la cartella che contiene il file .csproj).
3. Aprire **Esegui e debug**, selezionare **IdeaLab - F5 (browser)**, quindi F5.
4. Oppure dal terminale aperto nella cartella `IdeaLabPreview`: `dotnet run`.
5. Aprire `http://localhost:5084/` se il browser non si apre da solo.

Prima di iniziare devono funzionare la pagina e **Server online**.
La GET delle idee restituisce inizialmente `[]`: e' intenzionale.
Le API POST, PATCH e DELETE restituiscono 501 finche' non vengono completate.

## Cosa e' gia' pronto

- `Program.cs`: dependency injection, middleware statici, ping e scheletro API.
- `Models/Idea.cs`: tre normali **classi con `get; set;`**, nessun record o `init`.
- `Services/IdeaStore.cs`: un elenco di esempio in memoria e il prossimo ID.
- `wwwroot/index.html`: header, form ed elenco.
- `wwwroot/style.css`: grafica gia' pronta quasi interamente.
- `wwwroot/app.js`: ping, GET e prima parte del rendering gia' scritti.

## Cosa fare

1. Completare GET, POST, PATCH e DELETE in `Program.cs`.
2. In `app.js` aggiungere i due pulsanti, fare le richieste POST, PATCH e DELETE.
3. In `index.html` aggiungere un testo di aiuto, in `style.css` una regola `.helper`.

Per il PATCH basta:

```csharp
var idea = store.Items.Find(x => x.Id == id);
if (idea == null) return Results.NotFound();
idea.Approved = request.State;
return Results.Ok(idea);
```

Per il DELETE bastano `Find`, `Remove` e `Results.NoContent()`.
Non serve un database. Gli elementi aggiunti scompaiono al riavvio del server.
Non aprire `index.html` con Live Server: aprire la pagina da ASP.NET Core.
