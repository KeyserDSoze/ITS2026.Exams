// IdeaLab ITS: il ping e il GET sono gia' scritti come esempi.
const API = '/api/ideas';
const list = document.querySelector('#idea-list');
const form = document.querySelector('#idea-form');
const input = document.querySelector('#title');
const message = document.querySelector('#message');
const emptyMessage = document.querySelector('#empty-message');

// ESEMPIO PRONTO: chiamata a una Minimal API e lettura del JSON.
async function checkServer() {
  try {
    const response = await fetch('/api/ping');
    const data = await response.json();
    document.querySelector('#server-status').textContent = data.message;
    document.querySelector('#server-dot').classList.add('online');
  } catch (error) {
    document.querySelector('#server-status').textContent = 'Server non raggiungibile';
    document.querySelector('#server-dot').classList.add('offline');
  }
}

// ESEMPIO PRONTO: GET di tutte le proposte.
async function loadIdeas() {
  try {
    const response = await fetch(API);
    if (!response.ok) throw new Error('Errore nella lettura');
    const ideas = await response.json();
    renderIdeas(ideas);
  } catch (error) {
    showMessage('Impossibile leggere le proposte', true);
  }
}

function renderIdeas(ideas) {
  list.replaceChildren();
  emptyMessage.hidden = ideas.length > 0;

  // Parte della visualizzazione e' gia' preparata.
  for (const idea of ideas) {
    const li = document.createElement('li');
    li.className = 'idea-card';
    const text = document.createElement('span');
    text.textContent = idea.title + ' - ' + (idea.approved ? 'Approvata' : 'Da valutare');
    li.append(text);

    // TODO JS 1: crea un pulsante Approva/Riapri e collegalo a updateIdea().
    // TODO JS 2: crea un pulsante Elimina e collegalo a deleteIdea().

    list.append(li);
  }
}

// Il form non deve ricaricare la pagina.
form.addEventListener('submit', async (event) => {
  event.preventDefault();
  // TODO JS 3: invia un POST ad API con JSON { title: input.value }.
  // Se va bene, svuota il campo e richiama loadIdeas().
  showMessage('TODO: completa il POST del form');
});

// TODO JS 4: completa la richiesta PATCH; dopo il successo richiama loadIdeas().
async function updateIdea(id, state) {
  showMessage('TODO: completa il PATCH');
}

// TODO JS 5: completa la richiesta DELETE; dopo il successo richiama loadIdeas().
async function deleteIdea(id) {
  showMessage('TODO: completa il DELETE');
}

function showMessage(text, isError = false) {
  message.textContent = text;
  message.className = isError ? 'error' : 'success';
}

// Gia' funzionanti al primo avvio (anche senza completare i TODO).
checkServer();
loadIdeas();
