using IdeaLabPreview;

var builder = WebApplication.CreateBuilder(args);

// La DEPENDENCY INJECTION e' gia' pronta.
builder.Services.AddSingleton<IdeaStore>();

var app = builder.Build();

// I MIDDLEWARE sono gia' pronti: servono la pagina e gli altri file web.
app.UseDefaultFiles();
app.UseStaticFiles();

// Questo e' un esempio completo di Minimal API. NON modificarlo.
app.MapGet("/api/ping", () => Results.Ok(new
{
    status = "ok",
    message = "Server online"
}));

// =======================================================
// PROVA PRATICA: COMPLETARE LE QUATTRO MINIMAL API
// Modelli e IdeaStore sono gia' stati preparati.
// =======================================================

// TODO 1 - GET: restituisci store.Items al posto della lista vuota.
app.MapGet("/api/ideas", (IdeaStore store) =>
{
    return Results.Ok(new List<Idea>()); // TODO: sostituire
});

// TODO 2 - POST: leggi request.Title, usa Trim(), controlla che non
// sia vuoto; crea una Idea con new Idea { ... }, aggiungila alla lista.
// Se titolo non valido: 400 e JSON { error = "..." }.
// Se valido: 201 e JSON con la nuova Idea (Approved=false).
app.MapPost("/api/ideas", (CreateIdeaRequest request, IdeaStore store) =>
{
    return Results.StatusCode(501); // TODO: sostituire
});

// TODO 3 - PATCH: cerca con store.Items.Find(x => x.Id == id).
// Se non trovi l'idea: 404; altrimenti cambia idea.Approved = request.State
// e restituisci 200 con JSON dell'idea.
app.MapPatch("/api/ideas/{id:int}", (int id, UpdateIdeaState request, IdeaStore store) =>
{
    return Results.StatusCode(501); // TODO: sostituire
});

// TODO 4 - DELETE: cerca con Find(). Se non trovi: 404.
// Altrimenti rimuovi con store.Items.Remove(idea) e restituisci 204.
app.MapDelete("/api/ideas/{id:int}", (int id, IdeaStore store) =>
{
    return Results.StatusCode(501); // TODO: sostituire
});

app.Run();
