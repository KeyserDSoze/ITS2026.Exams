# Guida riservata al docente - IdeaLab ITS

Materiale di **simulazione didattica** preparato per mostrare agli studenti una prova simile per struttura e livello, senza distribuire le prove reali.

## Cosa mostrare in aula

1. Aprire il progetto **studente** e avviare F5.
2. Mostrare la pagina già impaginata e la scritta **Server online**.
3. Nel browser aprire `/api/ping` e `/api/ideas`: la prima risponde con JSON `status = ok`, la seconda con array temporaneamente vuoto.
4. Mostrare `Program.cs`: registrazione `AddSingleton<IdeaStore>()`, middleware e route già posizionate con TODO. Spiegare che lo studente scrive il corpo delle Minimal API.
5. Mostrare `wwwroot/app.js`: il fetch GET al ping è già funzionante e può fare da modello per le altre chiamate.
6. Far vedere `wwwroot/index.html` e `style.css`, quasi pronti.
7. Ricordare che la prova scritta è separata, con due domande di livello introduttivo.

## Verifiche consigliate

Il file `verifica_api.ps1` interroga l'app già avviata sullo stesso indirizzo e controlla i casi HTTP (per la soluzione completa, non per lo scheletro).

```powershell
cd .\Soluzione_IdeaLabPreview
dotnet run --launch-profile IdeaLabPreview
# In un secondo terminale:
cd ..
.erifica_api.ps1
```

## Nota operativa

Il progetto è stato controllato a livello di sorgenti e sintassi JavaScript; in questo ambiente non era disponibile il runtime .NET 10 per eseguire materialmente F5. Verificare l'apertura con F5 sul PC dell'aula prima di distribuirlo.
