param([string]$BaseUrl = 'http://localhost:5084')
$ErrorActionPreference = 'Stop'

function Assert([bool]$condition, [string]$description) {
    if (-not $condition) { throw "FAIL: $description" }
    Write-Host "OK: $description" -ForegroundColor Green
}
function HttpCode([string]$method, [string]$url, [string]$body = $null) {
    $args = @{ Uri = $url; Method = $method; UseBasicParsing = $true }
    if ($null -ne $body) {
        $args.ContentType = 'application/json'
        $args.Body = $body
    }
    try {
        $response = Invoke-WebRequest @args
        return [pscustomobject]@{
            StatusCode = [int]$response.StatusCode
            Content = [string]$response.Content
        }
    } catch {
        if (-not $_.Exception.Response) { throw }
        return [pscustomobject]@{
            StatusCode = [int]$_.Exception.Response.StatusCode
            Content = ''
        }
    }
}

$ping = Invoke-RestMethod "$BaseUrl/api/ping"
Assert ($ping.status -eq 'ok') 'Ping 200 e status ok'
$before = Invoke-RestMethod "$BaseUrl/api/ideas"
Assert (@($before).Count -ge 1) 'GET contiene dato di esempio'
$created = HttpCode 'Post' "$BaseUrl/api/ideas" '{"title":"  Laboratorio fotografia  "}'
Assert ($created.StatusCode -eq 201) 'POST valido -> 201'
$item = $created.Content | ConvertFrom-Json
Assert ($item.title -eq 'Laboratorio fotografia' -and $item.approved -eq $false) 'POST trim e stato iniziale'
$invalid = HttpCode 'Post' "$BaseUrl/api/ideas" '{"title":"   "}'
Assert ($invalid.StatusCode -eq 400) 'POST vuoto -> 400'
$patch = HttpCode 'Patch' "$BaseUrl/api/ideas/$($item.id)" '{"state":true}'
Assert ($patch.StatusCode -eq 200 -and ($patch.Content | ConvertFrom-Json).approved -eq $true) 'PATCH -> 200 e approved=true'
$del = HttpCode 'Delete' "$BaseUrl/api/ideas/$($item.id)"
Assert ($del.StatusCode -eq 204) 'DELETE -> 204'
Assert ((HttpCode 'Delete' "$BaseUrl/api/ideas/$($item.id)").StatusCode -eq 404) 'DELETE inesistente -> 404'
Write-Host 'TEST API COMPLETATI' -ForegroundColor Green
