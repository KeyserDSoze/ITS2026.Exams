const API = '/api/ideas';
const list = document.querySelector('#idea-list');
const form = document.querySelector('#idea-form');
const titleInput = document.querySelector('#title');
const message = document.querySelector('#message');
const emptyMessage = document.querySelector('#empty-message');
const searchInput = document.querySelector('#search');
let ideas = [];

async function checkServer() {
  const label = document.querySelector('#server-status');
  const dot = document.querySelector('#server-dot');
  try {
    const response = await fetch('/api/ping');
    if (!response.ok) throw new Error('Ping non riuscito');
    const data = await response.json();
    if (data.status !== 'ok') throw new Error('Risposta non valida');
    label.textContent = data.message;
    dot.classList.add('online');
  } catch (error) {
    label.textContent = 'Server non raggiungibile';
    dot.classList.add('offline');
    console.error('Ping:', error);
  }
}

function showMessage(text, isError = false) {
  message.textContent = text;
  message.className = isError ? 'error' : 'success';
}

async function loadIdeas() {
  try {
    const response = await fetch(API);
    if (!response.ok) throw new Error(`GET: HTTP ${response.status}`);
    ideas = await response.json();
    renderIdeas();
  } catch (error) {
    showMessage(`Impossibile caricare le proposte: ${error.message}`, true);
  }
}

function renderIdeas() {
  list.replaceChildren();
  const term = searchInput.value.trim().toLocaleLowerCase('it');
  const visible = ideas.filter(x => x.title.toLocaleLowerCase('it').includes(term));
  emptyMessage.hidden = visible.length > 0;
  emptyMessage.textContent = 'Nessuna proposta trovata.';

  for (const idea of visible) {
    const row = document.createElement('li');
    row.className = 'idea-card';
    const body = document.createElement('div');
    const name = document.createElement('span');
    name.className = 'idea-title';
    name.textContent = idea.title;
    const state = document.createElement('span');
    state.className = 'idea-state';
    state.textContent = idea.approved ? 'Approvata' : 'Da valutare';
    body.append(name, state);

    const buttons = document.createElement('div');
    buttons.className = 'idea-actions';
    const stateButton = document.createElement('button');
    stateButton.className = 'secondary';
    stateButton.textContent = idea.approved ? 'Riapri' : 'Approva';
    stateButton.addEventListener('click', () => updateState(idea.id, !idea.approved));
    const deleteButton = document.createElement('button');
    deleteButton.className = 'danger';
    deleteButton.textContent = 'Elimina';
    deleteButton.addEventListener('click', () => deleteIdea(idea.id));
    buttons.append(stateButton, deleteButton);
    row.append(body, buttons);
    list.append(row);
  }
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    const response = await fetch(API, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: titleInput.value })
    });
    if (!response.ok) {
      const body = await response.json().catch(() => ({}));
      throw new Error(body.error || `HTTP ${response.status}`);
    }
    titleInput.value = '';
    showMessage('Proposta registrata.');
    await loadIdeas();
  } catch (error) {
    showMessage(`Invio non riuscito: ${error.message}`, true);
  }
});

async function updateState(id, state) {
  try {
    const response = await fetch(`${API}/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ state })
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    showMessage('Stato aggiornato.');
    await loadIdeas();
  } catch (error) { showMessage(error.message, true); }
}

async function deleteIdea(id) {
  try {
    const response = await fetch(`${API}/${id}`, { method: 'DELETE' });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    showMessage('Proposta eliminata.');
    await loadIdeas();
  } catch (error) { showMessage(error.message, true); }
}

searchInput.addEventListener('input', renderIdeas);
checkServer();
loadIdeas();
