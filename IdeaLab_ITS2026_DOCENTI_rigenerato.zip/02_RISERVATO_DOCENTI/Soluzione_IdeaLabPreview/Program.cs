using IdeaLabPreview;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddSingleton<IdeaStore>();
builder.Services.AddProblemDetails();
var app = builder.Build();

if (app.Environment.IsDevelopment())
    app.UseDeveloperExceptionPage();
else
    app.UseExceptionHandler();

app.UseDefaultFiles();
app.UseStaticFiles();
app.UseRouting();

app.MapGet("/api/ping", () => Results.Ok(new { status = "ok", message = "Server online" }));

app.MapGet("/api/ideas", (IdeaStore store) => Results.Ok(store.Items));

app.MapPost("/api/ideas", (CreateIdeaRequest request, IdeaStore store) =>
{
    var title = request.Title?.Trim();
    if (string.IsNullOrWhiteSpace(title))
        return Results.BadRequest(new { error = "Il titolo e' obbligatorio." });

    var created = new Idea(store.NextId++, title, false);
    store.Items.Add(created);
    return Results.Created($"/api/ideas/{created.Id}", created);
});

app.MapPatch("/api/ideas/{id:int}", (int id, UpdateIdeaState request, IdeaStore store) =>
{
    var index = store.Items.FindIndex(x => x.Id == id);
    if (index < 0) return Results.NotFound();

    var updated = store.Items[index] with { Approved = request.State };
    store.Items[index] = updated;
    return Results.Ok(updated);
});

app.MapDelete("/api/ideas/{id:int}", (int id, IdeaStore store) =>
{
    var index = store.Items.FindIndex(x => x.Id == id);
    if (index < 0) return Results.NotFound();
    store.Items.RemoveAt(index);
    return Results.NoContent();
});

app.Run();
