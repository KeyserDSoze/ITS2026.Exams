# OrtoLab ITS - riservato al docente

Simulazione nuova, non esame reale. Valutazione proposta **20 punti pratica + 10 punti teoria**.

## Livello

La prova ripete le stesse abilita' base della precedente esercitazione IdeaLab, con un dominio diverso. Niente database, login, framework frontend, LINQ avanzato, record, init, with o FindIndex. Il ping e la GET JS sono gia' pronti, mentre il candidato completa quattro Minimal API e le interazioni frontend.

## Griglia pratica (20)

| Verifica | Punti |
|---|---:|
| Applicazione avviabile, ping e indicatore nella pagina | 2 |
| GET legge la lista PlantStore iniziale | 2 |
| POST valido: Trim, ID, stato false, HTTP 201 e JSON | 3 |
| POST non valido: HTTP 400, campo error, nessun inserimento | 2 |
| GET successiva mostra il nuovo record | 2 |
| PATCH cambia Watered usando Find, HTTP 200; ID assente 404 | 2 |
| DELETE rimuove elemento, HTTP 204; ID assente 404 | 2 |
| Lista visibile: nome, stato, pulsanti | 2 |
| Form e pulsanti funzionanti da browser | 2 |
| Paragrafo helper HTML + classe CSS helper | 1 |
| **TOTALE** | **20** |

## Domande aperte (5 + 5)

Domanda 1: OrtoLab e' un diario per le piante (1); consultare l'elenco (1); aggiungere/annaffiare/rimuovere (1); la pagina chiama le Minimal API (1); le API leggono/aggiornano e restituiscono dati JSON (1).

Domanda 2: GET legge i dati (1); POST crea (1); PATCH aggiorna Watered (1); DELETE elimina (1); esempio concreto coerente con OrtoLab (1).

## Prima della distribuzione

1. Avvia la soluzione completa su un PC con SDK .NET 10, testando pagina e operazioni.
2. Avvia `verifica_api.ps1` con la soluzione in esecuzione. Il test non sostituisce la prova manuale del browser.
3. Distribuisci soltanto la cartella STUDENTI. Non distribuire `Soluzione_OrtoLabPreview`.
4. Se il candidato avvia il progetto con Live Server invece che .NET, il ping non funzionera'.

Il progetto predisposto contiene un record di esempio "Basilico", ma la GET candidata torna `[]` fino al completamento del TODO: comportamento intenzionale.
