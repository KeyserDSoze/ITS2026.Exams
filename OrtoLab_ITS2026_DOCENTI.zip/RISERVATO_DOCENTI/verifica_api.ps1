param([string]$BaseUrl = "http://localhost:5092")
$ErrorActionPreference = 'Stop'

function Check($condition, $name) {
    if (-not $condition) { throw "ERRORE: $name" }
    Write-Host "OK: $name"
}

function Get-StatusOnError([scriptblock]$operation) {
    try {
        & $operation | Out-Null
        return 0
    } catch {
        if ($_.Exception.Response) { return [int]$_.Exception.Response.StatusCode }
        throw
    }
}

$ping = Invoke-RestMethod "$BaseUrl/api/ping"
Check ($ping.status -eq 'ok') 'GET ping'

$initial = @(Invoke-RestMethod "$BaseUrl/api/plants")
Check (@($initial | Where-Object { $_.name -eq 'Basilico' }).Count -gt 0) 'GET lista iniziale'

$created = Invoke-RestMethod "$BaseUrl/api/plants" -Method Post -ContentType 'application/json' -Body '{"name":"  Menta  "}'
Check ($created.name -eq 'Menta' -and $created.watered -eq $false) 'POST: Trim + stato false'

$all = @(Invoke-RestMethod "$BaseUrl/api/plants")
Check (@($all | Where-Object { $_.id -eq $created.id }).Count -eq 1) 'Nuova pianta presente in GET'

$bad = Get-StatusOnError { Invoke-RestMethod "$BaseUrl/api/plants" -Method Post -ContentType 'application/json' -Body '{"name":"   "}' }
Check ($bad -eq 400) 'POST senza nome -> HTTP 400'

$updated = Invoke-RestMethod "$BaseUrl/api/plants/$($created.id)" -Method Patch -ContentType 'application/json' -Body '{"state":true}'
Check ($updated.watered -eq $true) 'PATCH: pianta annaffiata'

Invoke-RestMethod "$BaseUrl/api/plants/$($created.id)" -Method Delete | Out-Null
$after = @(Invoke-RestMethod "$BaseUrl/api/plants")
Check (@($after | Where-Object { $_.id -eq $created.id }).Count -eq 0) 'DELETE: pianta assente'

$missingPatch = Get-StatusOnError { Invoke-RestMethod "$BaseUrl/api/plants/999999" -Method Patch -ContentType 'application/json' -Body '{"state":true}' }
Check ($missingPatch -eq 404) 'PATCH ID inesistente -> 404'
$missingDelete = Get-StatusOnError { Invoke-RestMethod "$BaseUrl/api/plants/999999" -Method Delete }
Check ($missingDelete -eq 404) 'DELETE ID inesistente -> 404'

Write-Host 'API principali verificate. Controllare manualmente sito e pulsanti nel browser.'
