namespace OrtoLabPreview;

// Un solo store in RAM per tutta l'app: il database non serve.
public class PlantStore
{
    public List<Plant> Items { get; set; } = new List<Plant>
    {
        new Plant { Id = 1, Name = "Basilico", Watered = false }
    };

    public int NextId { get; set; } = 2;
}
