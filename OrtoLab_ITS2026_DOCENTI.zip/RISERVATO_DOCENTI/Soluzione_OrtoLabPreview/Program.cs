using OrtoLabPreview;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddSingleton<PlantStore>();
var app = builder.Build();
app.UseDefaultFiles();
app.UseStaticFiles();

app.MapGet("/api/ping", () => Results.Ok(new
{
    status = "ok",
    message = "Server online"
}));

app.MapGet("/api/plants", (PlantStore store) => Results.Ok(store.Items));

app.MapPost("/api/plants", (CreatePlantRequest request, PlantStore store) =>
{
    var name = request.Name?.Trim();
    if (string.IsNullOrWhiteSpace(name))
        return Results.BadRequest(new { error = "Il nome della pianta e' obbligatorio" });

    var plant = new Plant
    {
        Id = store.NextId,
        Name = name,
        Watered = false
    };
    store.NextId++;
    store.Items.Add(plant);
    return Results.Created($"/api/plants/{plant.Id}", plant);
});

app.MapPatch("/api/plants/{id:int}", (int id, UpdatePlantState request, PlantStore store) =>
{
    var plant = store.Items.Find(x => x.Id == id);
    if (plant == null) return Results.NotFound();
    plant.Watered = request.State;
    return Results.Ok(plant);
});

app.MapDelete("/api/plants/{id:int}", (int id, PlantStore store) =>
{
    var plant = store.Items.Find(x => x.Id == id);
    if (plant == null) return Results.NotFound();
    store.Items.Remove(plant);
    return Results.NoContent();
});

app.Run();
