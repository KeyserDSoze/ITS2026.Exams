const API = '/api/plants';
const list = document.querySelector('#plant-list');
const form = document.querySelector('#plant-form');
const input = document.querySelector('#name');
const message = document.querySelector('#message');
const emptyMessage = document.querySelector('#empty-message');

async function checkServer() {
  try {
    const response = await fetch('/api/ping');
    if (!response.ok) throw new Error('Ping non riuscito');
    const data = await response.json();
    document.querySelector('#server-status').textContent = data.message;
    document.querySelector('#server-dot').classList.add('online');
  } catch (error) {
    document.querySelector('#server-status').textContent = 'Server non raggiungibile';
    document.querySelector('#server-dot').classList.add('offline');
  }
}

async function loadPlants() {
  try {
    const response = await fetch(API);
    if (!response.ok) throw new Error('Errore GET');
    const plants = await response.json();
    renderPlants(plants);
  } catch (error) {
    showMessage('Impossibile leggere le piante', true);
  }
}

function renderPlants(plants) {
  list.replaceChildren();
  emptyMessage.hidden = plants.length > 0;
  for (const plant of plants) {
    const li = document.createElement('li');
    li.className = 'plant-card';
    const text = document.createElement('span');
    text.textContent = plant.name + ' - ' + (plant.watered ? 'Annaffiata' : 'Da annaffiare');
    li.append(text);

    const buttons = document.createElement('div');
    buttons.className = 'plant-actions';
    const waterButton = document.createElement('button');
    waterButton.textContent = plant.watered ? 'Annulla' : 'Annaffia';
    waterButton.addEventListener('click', () => updatePlant(plant.id, !plant.watered));
    const deleteButton = document.createElement('button');
    deleteButton.className = 'delete';
    deleteButton.textContent = 'Elimina';
    deleteButton.addEventListener('click', () => deletePlant(plant.id));
    buttons.append(waterButton, deleteButton);
    li.append(buttons);
    list.append(li);
  }
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    const response = await fetch(API, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: input.value })
    });
    if (!response.ok) {
      showMessage('Nome non valido o errore del server', true);
      return;
    }
    input.value = '';
    showMessage('Pianta aggiunta');
    await loadPlants();
  } catch (error) { showMessage('Errore di rete', true); }
});

async function updatePlant(id, state) {
  try {
    const response = await fetch(API + '/' + id, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ state: state })
    });
    if (!response.ok) throw new Error('PATCH fallita');
    showMessage('Stato aggiornato');
    await loadPlants();
  } catch (error) { showMessage('Impossibile aggiornare la pianta', true); }
}

async function deletePlant(id) {
  try {
    const response = await fetch(API + '/' + id, { method: 'DELETE' });
    if (!response.ok) throw new Error('DELETE fallita');
    showMessage('Pianta eliminata');
    await loadPlants();
  } catch (error) { showMessage('Impossibile eliminare la pianta', true); }
}

function showMessage(text, isError = false) {
  message.textContent = text;
  message.className = isError ? 'error' : 'success';
}

checkServer();
loadPlants();
