namespace OrtoLabPreview;

// Usiamo classi con proprieta' modificabili (get; set;).
public class Plant
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public bool Watered { get; set; }
}

public class CreatePlantRequest
{
    public string? Name { get; set; }
}

public class UpdatePlantState
{
    public bool State { get; set; }
}
