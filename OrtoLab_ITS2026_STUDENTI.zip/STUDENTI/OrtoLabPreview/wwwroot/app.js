// OrtoLab ITS: il ping e il GET sono esempi gia' funzionanti.
const API = '/api/plants';
const list = document.querySelector('#plant-list');
const form = document.querySelector('#plant-form');
const input = document.querySelector('#name');
const message = document.querySelector('#message');
const emptyMessage = document.querySelector('#empty-message');

// ESEMPIO 1 - Ping: il server risponde con JSON.
async function checkServer() {
  try {
    const response = await fetch('/api/ping');
    if (!response.ok) throw new Error('Ping non riuscito');
    const data = await response.json();
    document.querySelector('#server-status').textContent = data.message;
    document.querySelector('#server-dot').classList.add('online');
  } catch (error) {
    document.querySelector('#server-status').textContent = 'Server non raggiungibile';
    document.querySelector('#server-dot').classList.add('offline');
  }
}

// ESEMPIO 2 - GET: carica la lista delle piante.
async function loadPlants() {
  try {
    const response = await fetch(API);
    if (!response.ok) throw new Error('Errore GET');
    const plants = await response.json();
    renderPlants(plants);
  } catch (error) {
    showMessage('Impossibile leggere le piante', true);
  }
}

function renderPlants(plants) {
  list.replaceChildren();
  emptyMessage.hidden = plants.length > 0;

  for (const plant of plants) {
    const li = document.createElement('li');
    li.className = 'plant-card';
    const text = document.createElement('span');
    text.textContent = plant.name + ' - ' + (plant.watered ? 'Annaffiata' : 'Da annaffiare');
    li.append(text);

    // TODO JS 1: aggiungi un pulsante Annaffia/Annulla.
    // Al click chiama updatePlant(plant.id, !plant.watered).
    // TODO JS 2: aggiungi un pulsante Elimina che chiama deletePlant(plant.id).

    list.append(li);
  }
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  // TODO JS 3: usa fetch(API) con method: 'POST'.
  // Invia headers Content-Type: application/json e body JSON.stringify({ name: input.value }).
  // Se va bene, svuota input, mostra un messaggio e chiama loadPlants().
  showMessage('TODO: completa la richiesta POST');
});

async function updatePlant(id, state) {
  // TODO JS 4: usa fetch(API + '/' + id) con method: 'PATCH'
  // e body JSON.stringify({ state: state }), poi chiama loadPlants().
  showMessage('TODO: completa la richiesta PATCH');
}

async function deletePlant(id) {
  // TODO JS 5: usa fetch(API + '/' + id) con method: 'DELETE',
  // poi chiama loadPlants().
  showMessage('TODO: completa la richiesta DELETE');
}

function showMessage(text, isError = false) {
  message.textContent = text;
  message.className = isError ? 'error' : 'success';
}

checkServer();
loadPlants();
