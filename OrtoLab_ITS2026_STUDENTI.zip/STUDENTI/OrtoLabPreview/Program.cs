using OrtoLabPreview;

var builder = WebApplication.CreateBuilder(args);

// Dependency Injection: gia' configurata.
builder.Services.AddSingleton<PlantStore>();

var app = builder.Build();

// Middleware: servono automaticamente index.html, CSS e JavaScript.
app.UseDefaultFiles();
app.UseStaticFiles();

// ESEMPIO COMPLETO: non modificare il ping.
app.MapGet("/api/ping", () => Results.Ok(new
{
    status = "ok",
    message = "Server online"
}));

// ==============================================================
// ESERCITAZIONE: completare le 4 Minimal API qui sotto.
// Plant, CreatePlantRequest, UpdatePlantState e PlantStore
// sono gia' predisposti. Non occorre creare altre classi.
// ==============================================================

// TODO GET: restituisci la lista store.Items (al momento e' vuota).
app.MapGet("/api/plants", (PlantStore store) =>
{
    return Results.Ok(new List<Plant>()); // TODO
});

// TODO POST: leggi request.Name, usa Trim e valida il nome.
// Se mancante/vuoto/spazi: HTTP 400 con { error = "..." }.
// Altrimenti crea una Plant (Watered = false), usa store.NextId,
// aggiungi a store.Items e rispondi HTTP 201 con la nuova pianta.
app.MapPost("/api/plants", (CreatePlantRequest request, PlantStore store) =>
{
    return Results.StatusCode(501); // TODO
});

// TODO PATCH: cerca con store.Items.Find(x => x.Id == id).
// Se non esiste: 404. Altrimenti plant.Watered = request.State
// e restituisci 200 con l'oggetto aggiornato.
app.MapPatch("/api/plants/{id:int}", (int id, UpdatePlantState request, PlantStore store) =>
{
    return Results.StatusCode(501); // TODO
});

// TODO DELETE: trova la pianta con Find(). Se non esiste: 404.
// Altrimenti store.Items.Remove(plant) e restituisci HTTP 204.
app.MapDelete("/api/plants/{id:int}", (int id, PlantStore store) =>
{
    return Results.StatusCode(501); // TODO
});

app.Run();
