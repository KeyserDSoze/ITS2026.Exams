# OrtoLab ITS - esercitazione Development

Questa e' una nuova simulazione didattica, indipendente dagli esami reali.
Trovi una prova pratica, una prova teorica e il progetto .NET 10 gia' predisposto.

## Avvio rapido con VS Code

1. Installa **.NET SDK 10** e l'estensione **C#** di Microsoft.
2. In VS Code scegli **File > Apri cartella** e apri **OrtoLabPreview** (dove c'e' il file `.csproj`).
3. Da **Esegui e debug** scegli **OrtoLab - F5 (browser)** e premi **F5**.
4. Oppure, apri il terminale in quella cartella ed esegui `dotnet run`.
5. Se il browser non si apre automaticamente, visita `http://localhost:5092/`.

Devi gia' vedere **OrtoLab ITS** e **Server online** senza toccare il codice.
Il ping `GET /api/ping` e' completo. Il GET piante restituisce per ora `[]`;
POST, PATCH e DELETE restituiscono 501 finche' non completi i TODO.

## File da modificare

- `Program.cs`: completare GET, POST, PATCH, DELETE.
- `wwwroot/app.js`: completare i pulsanti e le richieste POST, PATCH, DELETE.
- `wwwroot/index.html`: aggiungere un paragrafo informativo `.helper`.
- `wwwroot/style.css`: aggiungere la classe `.helper`.

Gia' pronti: dependency injection, middleware, modelli, lista in memoria, ping, HTML, CSS e chiamata JS GET.
Le classi hanno proprieta' `get; set;`, quindi si puo' usare `Find()` e assegnare direttamente `plant.Watered = request.State`.
Non serve database, non serve autenticazione. I dati si perdono alla chiusura dell'app.

**Non avviare index.html con Live Server:** la pagina deve provenire dal backend .NET.

## Prova rapida

- `http://localhost:5092/` mostra il sito.
- `http://localhost:5092/api/ping` mostra un JSON con `status: "ok"`.
- `http://localhost:5092/api/plants` mostra `[]` prima di completare il GET.
- Nel file `OrtoLabPreview.http` trovi esempi di richieste da usare con un client HTTP.

Compila anche `domanda1.txt` e `domanda2.txt` per esercitarti con la teoria.
