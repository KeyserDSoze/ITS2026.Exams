using CucinaLabPreview;

var builder = WebApplication.CreateBuilder(args);

// Dependency Injection: gia' pronta.
builder.Services.AddSingleton<RecipeStore>();

var app = builder.Build();

// Middleware: la pagina HTML, il CSS e il JS sono gia' serviti dal backend.
app.UseDefaultFiles();
app.UseStaticFiles();

// ESEMPIO COMPLETO: non modificare questa Minimal API.
app.MapGet("/api/ping", () => Results.Ok(new
{
    status = "ok",
    message = "Server online"
}));

// ==============================================================
// ESERCITAZIONE: completa qui le 4 Minimal API.
// Recipe, CreateRecipeRequest, UpdateRecipeState e RecipeStore
// esistono gia'. Nessuna nuova classe o database da creare.
// ==============================================================

// TODO GET: restituisci la vera lista store.Items.
app.MapGet("/api/recipes", (RecipeStore store) =>
{
    return Results.Ok(new List<Recipe>()); // TODO: sostituire
});

// TODO POST: leggi request.Name, applica Trim() e valida.
// Nome mancante o fatto solo di spazi: 400 con { error = "..." }.
// Altrimenti usa store.NextId, crea Recipe (Tried = false),
// aggiungila a store.Items e restituisci 201 con la ricetta.
app.MapPost("/api/recipes", (CreateRecipeRequest request, RecipeStore store) =>
{
    return Results.StatusCode(501); // TODO
});

// TODO PATCH: cerca usando store.Items.Find(x => x.Id == id).
// Se assente: 404. Altrimenti recipe.Tried = request.State;
// e restituisci 200 con la ricetta aggiornata.
app.MapPatch("/api/recipes/{id:int}", (int id, UpdateRecipeState request, RecipeStore store) =>
{
    return Results.StatusCode(501); // TODO
});

// TODO DELETE: usa Find() per cercare la ricetta.
// Se assente: 404. Altrimenti store.Items.Remove(recipe) e torna 204.
app.MapDelete("/api/recipes/{id:int}", (int id, RecipeStore store) =>
{
    return Results.StatusCode(501); // TODO
});

app.Run();
