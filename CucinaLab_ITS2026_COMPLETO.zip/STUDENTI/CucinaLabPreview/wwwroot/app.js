const API = '/api/recipes';
const list = document.querySelector('#recipe-list');
const form = document.querySelector('#recipe-form');
const input = document.querySelector('#name');
const message = document.querySelector('#message');
const emptyMessage = document.querySelector('#empty-message');

// ESEMPIO 1: ping gia' funzionante.
async function checkServer() {
  try {
    const response = await fetch('/api/ping');
    if (!response.ok) throw new Error('Ping non riuscito');
    const data = await response.json();
    document.querySelector('#server-status').textContent = data.message;
    document.querySelector('#server-dot').classList.add('online');
  } catch (error) {
    document.querySelector('#server-status').textContent = 'Server non raggiungibile';
    document.querySelector('#server-dot').classList.add('offline');
  }
}

// ESEMPIO 2: GET gia' scritto; usa la Minimal API che completerai in C#.
async function loadRecipes() {
  try {
    const response = await fetch(API);
    if (!response.ok) throw new Error('Errore GET');
    const recipes = await response.json();
    renderRecipes(recipes);
  } catch (error) {
    showMessage('Impossibile caricare le ricette', true);
  }
}

function renderRecipes(recipes) {
  list.replaceChildren();
  emptyMessage.hidden = recipes.length > 0;

  for (const recipe of recipes) {
    const li = document.createElement('li');
    li.className = 'recipe-card';
    const text = document.createElement('span');
    text.textContent = recipe.name + ' - ' + (recipe.tried ? 'Provata' : 'Da provare');
    li.append(text);

    // TODO JS 1: crea un pulsante "Segna provata" / "Da provare".
    // Al click chiama updateRecipe(recipe.id, !recipe.tried).
    // TODO JS 2: crea un pulsante "Elimina" che chiama deleteRecipe(recipe.id).

    list.append(li);
  }
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  // TODO JS 3: invia un POST con fetch(API), Content-Type JSON e
  // body JSON.stringify({ name: input.value }).
  // Se successo, svuota input, mostra messaggio e richiama loadRecipes().
  showMessage('TODO: completa il POST');
});

async function updateRecipe(id, state) {
  // TODO JS 4: fetch(API + '/' + id) con method: 'PATCH',
  // Content-Type JSON, body JSON.stringify({ state: state }).
  // Controlla response.ok e richiama loadRecipes().
  showMessage('TODO: completa il PATCH');
}

async function deleteRecipe(id) {
  // TODO JS 5: fetch(API + '/' + id) con method: 'DELETE'.
  // Controlla response.ok e richiama loadRecipes().
  showMessage('TODO: completa il DELETE');
}

function showMessage(text, isError = false) {
  message.textContent = text;
  message.className = isError ? 'error' : 'success';
}

checkServer();
loadRecipes();
