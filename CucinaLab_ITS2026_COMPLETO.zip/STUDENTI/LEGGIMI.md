# CucinaLab ITS - Terza esercitazione Development

Simulazione didattica indipendente dalle tracce d'esame reali.

## Avvio rapido da VS Code

1. Installa .NET SDK 10 e l'estensione C# di Microsoft per VS Code.
2. Apri come cartella **CucinaLabPreview** (quella con `CucinaLabPreview.csproj`).
3. In Esegui e debug scegli **CucinaLab - F5 (browser)** e premi F5.
4. Oppure apri il terminale nella cartella e digita `dotnet run`.
5. Apri `http://localhost:5096/` se il browser non si apre automaticamente.

La pagina **CucinaLab ITS** e il messaggio **Server online** funzionano gia':
`GET /api/ping` e il relativo `fetch()` JavaScript sono completi.
Il GET delle ricette restituisce inizialmente `[]` finche' non completi il TODO.
POST, PATCH e DELETE rispondono temporaneamente con HTTP 501.

## Cosa completare

- `Program.cs`: GET, POST, PATCH, DELETE delle ricette.
- `wwwroot/app.js`: POST del form, pulsanti e richieste PATCH/DELETE.
- `wwwroot/index.html`: paragrafo informativo `.helper`.
- `wwwroot/style.css`: stile `.helper`.
- `domanda1.txt`, `domanda2.txt`: domande della prova teorica.

I modelli sono gia' classi con `get; set;`. Per PATCH usa `Find()` e
`recipe.Tried = request.State;`; per DELETE usa `Find()` e `Remove()`.
Niente database, autenticazione, librerie aggiuntive o framework frontend.

Per fare debug usa un breakpoint in `Program.cs`, quindi F5 e una richiesta
nel browser o con `CucinaLabPreview.http` (con una estensione client HTTP).

**Non usare Live Server per `index.html`:** il sito deve essere servito da .NET.
I dati delle ricette restano in RAM e si perdono quando spegni l'app.
