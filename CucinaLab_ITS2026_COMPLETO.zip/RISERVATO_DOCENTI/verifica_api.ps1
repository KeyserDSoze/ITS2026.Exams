param([string]$BaseUrl = "http://localhost:5096")
$ErrorActionPreference = 'Stop'

function Check($condition, $name) {
    if (-not $condition) { throw "ERRORE: $name" }
    Write-Host "OK: $name"
}
function Get-StatusOnError([scriptblock]$operation) {
    try { & $operation | Out-Null; return 0 }
    catch {
        if ($_.Exception.Response) { return [int]$_.Exception.Response.StatusCode }
        throw
    }
}

$ping = Invoke-RestMethod "$BaseUrl/api/ping"
Check ($ping.status -eq 'ok') 'Ping online'

$initial = @(Invoke-RestMethod "$BaseUrl/api/recipes")
Check (@($initial | Where-Object { $_.name -eq 'Pasta al pomodoro' }).Count -gt 0) 'GET iniziale'

$created = Invoke-RestMethod "$BaseUrl/api/recipes" -Method Post -ContentType 'application/json' -Body '{"name":"  Torta di mele  "}'
Check ($created.name -eq 'Torta di mele' -and $created.tried -eq $false -and $created.id -gt 0) 'POST valido con Trim e default false'

$all = @(Invoke-RestMethod "$BaseUrl/api/recipes")
Check (@($all | Where-Object { $_.id -eq $created.id }).Count -eq 1) 'Persistenza in memoria'

$bad = Get-StatusOnError { Invoke-RestMethod "$BaseUrl/api/recipes" -Method Post -ContentType 'application/json' -Body '{"name":"   "}' }
Check ($bad -eq 400) 'POST nome vuoto -> 400'

$updated = Invoke-RestMethod "$BaseUrl/api/recipes/$($created.id)" -Method Patch -ContentType 'application/json' -Body '{"state":true}'
Check ($updated.tried -eq $true) 'PATCH true'

$updatedBack = Invoke-RestMethod "$BaseUrl/api/recipes/$($created.id)" -Method Patch -ContentType 'application/json' -Body '{"state":false}'
Check ($updatedBack.tried -eq $false) 'PATCH false'

$missingPatch = Get-StatusOnError { Invoke-RestMethod "$BaseUrl/api/recipes/999999" -Method Patch -ContentType 'application/json' -Body '{"state":true}' }
Check ($missingPatch -eq 404) 'PATCH inesistente -> 404'

Invoke-RestMethod "$BaseUrl/api/recipes/$($created.id)" -Method Delete | Out-Null
$after = @(Invoke-RestMethod "$BaseUrl/api/recipes")
Check (@($after | Where-Object { $_.id -eq $created.id }).Count -eq 0) 'DELETE elimina'

$missingDelete = Get-StatusOnError { Invoke-RestMethod "$BaseUrl/api/recipes/999999" -Method Delete }
Check ($missingDelete -eq 404) 'DELETE inesistente -> 404'

Write-Host 'Controlli API completati. Verificare nel browser le interazioni JavaScript.'
