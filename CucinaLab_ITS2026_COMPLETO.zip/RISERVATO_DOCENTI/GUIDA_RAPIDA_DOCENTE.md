# CucinaLab ITS - Indicazioni per il docente (riservato)

Esercitazione autonoma: non distribuire la cartella RISERVATO_DOCENTI.

## Struttura

- `STUDENTI/CucinaLabPreview` (nel pacchetto studenti): codice incompleto, ma avviabile.
- `RISERVATO_DOCENTI/Soluzione_CucinaLabPreview`: codice completo.
- `verifica_api.ps1`: collaudo degli endpoint dopo l'avvio della soluzione.
- `Guida_docente_CucinaLab.pdf`: risposte attese e griglia dei punteggi.

## Esecuzione soluzione

```powershell
cd Soluzione_CucinaLabPreview
dotnet run
```

Il progetto usa .NET SDK 10 e http://localhost:5096/. In un secondo terminale:

```powershell
.\verifica_api.ps1 -BaseUrl http://localhost:5096
```

Se `verifica_api.ps1` e' nella directory superiore, lancialo da li'.
Il collaudo controlla ping, GET iniziale, POST 201, Trim, POST 400, PATCH, DELETE, 404.
Verificare in browser anche i pulsanti, gli stati, il form e la classe `.helper`.

## Soluzione C# semplificata

- `public class` con proprieta' `get; set;` per tutti i modelli.
- POST con validazione `string.IsNullOrWhiteSpace`, incremento `NextId`.
- PATCH con `var recipe = store.Items.Find(x => x.Id == id);` e `recipe.Tried = request.State;`.
- DELETE con `Find()` e `Remove()`.
- Nessun record, `init`, `with`, `FindIndex`, database o autenticazione.

Correzione tecnica: 20 punti. Domande aperte: 10 punti. I PDF distribuiti ai candidati non indicano punteggi.
