const API = '/api/recipes';
const list = document.querySelector('#recipe-list');
const form = document.querySelector('#recipe-form');
const input = document.querySelector('#name');
const message = document.querySelector('#message');
const emptyMessage = document.querySelector('#empty-message');

// ESEMPIO 1: ping gia' funzionante.
async function checkServer() {
  try {
    const response = await fetch('/api/ping');
    if (!response.ok) throw new Error('Ping non riuscito');
    const data = await response.json();
    document.querySelector('#server-status').textContent = data.message;
    document.querySelector('#server-dot').classList.add('online');
  } catch (error) {
    document.querySelector('#server-status').textContent = 'Server non raggiungibile';
    document.querySelector('#server-dot').classList.add('offline');
  }
}

// ESEMPIO 2: GET gia' scritto; usa la Minimal API che completerai in C#.
async function loadRecipes() {
  try {
    const response = await fetch(API);
    if (!response.ok) throw new Error('Errore GET');
    const recipes = await response.json();
    renderRecipes(recipes);
  } catch (error) {
    showMessage('Impossibile caricare le ricette', true);
  }
}

function renderRecipes(recipes) {
  list.replaceChildren();
  emptyMessage.hidden = recipes.length > 0;

  for (const recipe of recipes) {
    const li = document.createElement('li');
    li.className = 'recipe-card';
    const text = document.createElement('span');
    text.textContent = recipe.name + ' - ' + (recipe.tried ? 'Provata' : 'Da provare');
    li.append(text);

    const buttons = document.createElement('div');
    buttons.className = 'recipe-actions';
    const tryButton = document.createElement('button');
    tryButton.textContent = recipe.tried ? 'Da provare' : 'Segna provata';
    tryButton.addEventListener('click', () => updateRecipe(recipe.id, !recipe.tried));
    const deleteButton = document.createElement('button');
    deleteButton.className = 'delete';
    deleteButton.textContent = 'Elimina';
    deleteButton.addEventListener('click', () => deleteRecipe(recipe.id));
    buttons.append(tryButton, deleteButton);
    li.append(buttons);

    list.append(li);
  }
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    const response = await fetch(API, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: input.value })
    });
    if (!response.ok) {
      showMessage('Nome non valido o errore del server', true);
      return;
    }
    input.value = '';
    showMessage('Ricetta aggiunta');
    await loadRecipes();
  } catch (error) { showMessage('Errore di rete', true); }
});

async function updateRecipe(id, state) {
  try {
    const response = await fetch(API + '/' + id, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ state: state })
    });
    if (!response.ok) throw new Error('PATCH fallita');
    showMessage('Stato aggiornato');
    await loadRecipes();
  } catch (error) { showMessage('Impossibile aggiornare la ricetta', true); }
}

async function deleteRecipe(id) {
  try {
    const response = await fetch(API + '/' + id, { method: 'DELETE' });
    if (!response.ok) throw new Error('DELETE fallita');
    showMessage('Ricetta eliminata');
    await loadRecipes();
  } catch (error) { showMessage('Impossibile eliminare la ricetta', true); }
}

function showMessage(text, isError = false) {
  message.textContent = text;
  message.className = isError ? 'error' : 'success';
}

checkServer();
loadRecipes();
