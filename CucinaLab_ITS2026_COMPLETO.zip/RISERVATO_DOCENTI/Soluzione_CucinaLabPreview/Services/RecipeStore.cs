namespace CucinaLabPreview;

// Lista condivisa in memoria; nessun database.
public class RecipeStore
{
    public List<Recipe> Items { get; set; } = new List<Recipe>
    {
        new Recipe { Id = 1, Name = "Pasta al pomodoro", Tried = false }
    };

    public int NextId { get; set; } = 2;
}
