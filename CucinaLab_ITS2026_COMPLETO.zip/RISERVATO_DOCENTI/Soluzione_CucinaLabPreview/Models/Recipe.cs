namespace CucinaLabPreview;

// Tutte le proprieta' sono modificabili con get; set;.
public class Recipe
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public bool Tried { get; set; }
}

public class CreateRecipeRequest
{
    public string? Name { get; set; }
}

public class UpdateRecipeState
{
    public bool State { get; set; }
}
