using CucinaLabPreview;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddSingleton<RecipeStore>();
var app = builder.Build();
app.UseDefaultFiles();
app.UseStaticFiles();

app.MapGet("/api/ping", () => Results.Ok(new
{
    status = "ok",
    message = "Server online"
}));

app.MapGet("/api/recipes", (RecipeStore store) => Results.Ok(store.Items));

app.MapPost("/api/recipes", (CreateRecipeRequest request, RecipeStore store) =>
{
    var name = request.Name?.Trim();
    if (string.IsNullOrWhiteSpace(name))
        return Results.BadRequest(new { error = "Il nome della ricetta e' obbligatorio" });

    var recipe = new Recipe
    {
        Id = store.NextId,
        Name = name,
        Tried = false
    };
    store.NextId++;
    store.Items.Add(recipe);
    return Results.Created($"/api/recipes/{recipe.Id}", recipe);
});

app.MapPatch("/api/recipes/{id:int}", (int id, UpdateRecipeState request, RecipeStore store) =>
{
    var recipe = store.Items.Find(x => x.Id == id);
    if (recipe == null) return Results.NotFound();
    recipe.Tried = request.State;
    return Results.Ok(recipe);
});

app.MapDelete("/api/recipes/{id:int}", (int id, RecipeStore store) =>
{
    var recipe = store.Items.Find(x => x.Id == id);
    if (recipe == null) return Results.NotFound();
    store.Items.Remove(recipe);
    return Results.NoContent();
});

app.Run();
