using IdeaLabPreview;

var builder = WebApplication.CreateBuilder(args);

// DEPENDENCY INJECTION: gia' configurata. Non e' necessario modificarla.
builder.Services.AddSingleton<IdeaStore>();
builder.Services.AddProblemDetails();

var app = builder.Build();

// MIDDLEWARE: gia' configurati.
if (app.Environment.IsDevelopment())
    app.UseDeveloperExceptionPage();
else
    app.UseExceptionHandler();

app.UseDefaultFiles();    // Serve automaticamente wwwroot/index.html
app.UseStaticFiles();     // Serve CSS, JavaScript e altri file statici
app.UseRouting();

// ESEMPIO COMPLETO: il frontend lo chiama al caricamento per mostrare Server online.
app.MapGet("/api/ping", () => Results.Ok(new
{
    status = "ok",
    message = "Server online"
}));

// ================================================================
// PROVA PRATICA - COMPLETARE LE MINIMAL API QUI SOTTO
// ================================================================

// TODO 1 - GET: restituisci tutti i dati presenti in store.Items.
// All'inizio questa API restituisce volutamente un elenco vuoto.
app.MapGet("/api/ideas", (IdeaStore store) =>
{
    return Results.Ok(Array.Empty<Idea>()); // SOSTITUIRE QUESTA RIGA
});

// TODO 2 - POST: valida Title, esegui Trim, assegna store.NextId,
// salva una nuova Idea con Approved=false e restituisci 201.
// Input vuoto / soli spazi -> 400 con { "error": "..." }.
app.MapPost("/api/ideas", (CreateIdeaRequest request, IdeaStore store) =>
{
    return Results.StatusCode(501); // SOSTITUIRE QUESTA RIGA
});

// TODO 3 - PATCH: cerca l'id; se non esiste -> 404.
// Se esiste aggiorna soltanto Approved con request.State -> 200 + JSON.
app.MapPatch("/api/ideas/{id:int}", (int id, UpdateIdeaState request, IdeaStore store) =>
{
    return Results.StatusCode(501); // SOSTITUIRE QUESTA RIGA
});

// TODO 4 - DELETE: se id non esiste -> 404; altrimenti rimuovi -> 204.
app.MapDelete("/api/ideas/{id:int}", (int id, IdeaStore store) =>
{
    return Results.StatusCode(501); // SOSTITUIRE QUESTA RIGA
});

app.Run();
