namespace IdeaLabPreview;

// Il contenitore dati e la registrazione in dependency injection sono gia' pronti.
// I dati restano in memoria e si azzerano quando il server viene riavviato.
public sealed class IdeaStore
{
    public List<Idea> Items { get; } = new()
    {
        new Idea(1, "Laboratorio modellazione 3D", false)
    };

    public int NextId { get; set; } = 2;
}
