// IdeaLab ITS - ESEMPIO PRONTO + FUNZIONI DA COMPLETARE
// In DevTools > Network puoi osservare tutte le chiamate HTTP.
const API = '/api/ideas';
const list = document.querySelector('#idea-list');
const form = document.querySelector('#idea-form');
const titleInput = document.querySelector('#title');
const message = document.querySelector('#message');
const emptyMessage = document.querySelector('#empty-message');
let ideas = [];

// ESEMPIO GIA' FUNZIONANTE - GET a una Minimal API e lettura JSON.
async function checkServer() {
  const label = document.querySelector('#server-status');
  const dot = document.querySelector('#server-dot');
  try {
    const response = await fetch('/api/ping');
    if (!response.ok) throw new Error('Ping non riuscito');
    const data = await response.json();
    if (data.status !== 'ok') throw new Error('Risposta non valida');
    label.textContent = data.message; // "Server online"
    dot.classList.add('online');
  } catch (error) {
    label.textContent = 'Server non raggiungibile';
    dot.classList.add('offline');
    console.error('Ping:', error);
  }
}

// ESEMPIO DI GET GIA' IMPOSTATO: manca la visualizzazione dei dati.
async function loadIdeas() {
  try {
    const response = await fetch(API);
    if (!response.ok) throw new Error(`GET: HTTP ${response.status}`);
    ideas = await response.json();
    // TODO JS 1: completa renderIdeas() per visualizzare l'array "ideas".
    renderIdeas();
  } catch (error) {
    showMessage(`Impossibile caricare le proposte: ${error.message}`, true);
  }
}

function renderIdeas() {
  list.replaceChildren();
  emptyMessage.hidden = ideas.length > 0;
  // TODO JS 2: creare per ogni proposta un <li> con document.createElement
  // e scrivere il testo usando textContent (non innerHTML).
  // TODO JS 3: mostrare lo stato Approvata / Da valutare.
  // TODO JS 4: aggiungere pulsanti Approva/Riapri (PATCH) ed Elimina (DELETE).
  // TODO JS 5: usare l'input #search per filtrare le proposte nel browser.
}

// Il submit del form e' gia' collegato: completa la richiesta di creazione.
form.addEventListener('submit', async (event) => {
  event.preventDefault(); // Non ricarica la pagina
  const title = titleInput.value;

  // TODO JS 6: eseguire fetch(API, { method: 'POST', headers: ..., body: ... })
  // passando JSON { title }. Puoi copiare la struttura di checkServer/loadIdeas.
  // TODO JS 7: se risposta 201, pulisci il campo, mostra un messaggio
  // e richiama loadIdeas(); se risposta 400, mostra l'errore.
  showMessage('Da completare: invio della proposta dal form.');
});

function showMessage(text, isError = false) {
  message.textContent = text;
  message.className = isError ? 'error' : 'success';
}

// TODO JS 8: intercettare l'evento input su #search e richiamare renderIdeas().
// Usa ?. perche' inizialmente #search non e' ancora presente nell'HTML.

// ESECUZIONE ALL'AVVIO: tutto funziona anche con i TODO ancora vuoti.
checkServer();
loadIdeas();
