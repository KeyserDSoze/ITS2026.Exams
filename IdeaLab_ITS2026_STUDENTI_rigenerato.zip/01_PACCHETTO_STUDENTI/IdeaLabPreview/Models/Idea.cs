namespace IdeaLabPreview;

// Record da utilizzare nelle Minimal API.
public record Idea(int Id, string Title, bool Approved);
public record CreateIdeaRequest(string? Title);
public record UpdateIdeaState(bool State);
