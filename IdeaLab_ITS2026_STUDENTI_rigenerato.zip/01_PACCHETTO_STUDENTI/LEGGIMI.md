# Simulazione Development ITS - IdeaLab

Questa è una **simulazione didattica**, non una traccia d'esame ufficiale.
La cartella contiene un progetto .NET 10 già predisposto: **non devi crearlo da zero**.

## Partenza veloce (Visual Studio)

1. Verifica che siano presenti **.NET SDK 10** e **Visual Studio 2026 (18.0+)** con workload **ASP.NET e sviluppo Web**.
2. Apri `IdeaLabPreview.sln` (o `IdeaLabPreview.csproj`) in Visual Studio.
3. Imposta `IdeaLabPreview` come progetto di avvio, se necessario.
4. Premi **F5**. Il profilo `IdeaLabPreview` apre `http://localhost:5084/`.
5. Dovresti vedere la pagina **IdeaLab ITS** e la scritta **Server online**.

Alternativa da terminale: `dotnet run --project IdeaLabPreview.csproj --launch-profile IdeaLabPreview`.
Con Visual Studio Code: apri questa stessa cartella, installa l'estensione C# Microsoft, poi usa F5 con la configurazione fornita.

## Cosa trovi già pronto

- `Program.cs`: dependency injection, middleware, file statici, endpoint **GET /api/ping** funzionante, quattro API da completare.
- `Models/Idea.cs`: struttura dell'oggetto e richieste JSON.
- `Services/IdeaStore.cs`: lista in memoria e identificativo successivo, registrata come singleton in dependency injection.
- `wwwroot/index.html`: pagina, modulo di inserimento, area di elenco e stato server.
- `wwwroot/style.css`: stile base già funzionante.
- `wwwroot/app.js`: richiesta **fetch('/api/ping')** funzionante; GET impostata; punti TODO per elenco, inserimento, approvazione, eliminazione e filtro.

## Cosa succede prima che tu scriva codice

- `GET /api/ping` -> HTTP 200 e JSON con `status: "ok"`.
- La pagina mostra **Server online** e la sezione Proposte ricevute è vuota.
- `GET /api/ideas` -> HTTP 200, `[]` temporaneo: va modificato per leggere lo store.
- `POST`, `PATCH`, `DELETE` -> HTTP 501 **voluto** (funzionalità non implementate).
- Il form visualizza un messaggio di lavoro da completare.

## Ordine di lavoro consigliato

1. `Program.cs`: GET, poi POST con validazione, poi PATCH e DELETE.
2. `app.js`: visualizzazione con `createElement` / `textContent`, invio POST, pulsanti PATCH/DELETE, ricerca.
3. `index.html` e `style.css`: aggiungi i pochi elementi e gli stili mancanti.
4. Prova i casi normali ed errati usando il browser e DevTools > Network.

## Importante

- I dati restano soltanto in memoria: al riavvio si riparte dal record di esempio.
- Non sono richiesti database, autenticazione o librerie frontend.
- Per la consegna si usa l'intera cartella del progetto con i file modificati.
- La soluzione docente **non è contenuta** in questo pacchetto.
